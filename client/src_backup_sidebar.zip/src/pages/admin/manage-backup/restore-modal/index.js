import React, { useState } from 'react'
import './style.module.scss'
import {
    Modal
} from 'antd'

import { FileAddOutlined } from '@ant-design/icons'

import { useTranslation } from 'react-i18next';
import { useDropzone } from 'react-dropzone'

const RestoreModal = props => {
    const { t } = useTranslation(['common']);

    const {isVisible, setVisible} = props
    const [confirmLoading, setConfirmLoading] = useState(false);
    const [files, setFiles] = useState([])

    const handleOk = () => {
        setConfirmLoading(true);
        setTimeout(() => {
        setVisible(false);
        setConfirmLoading(false);
        }, 2000);
    };

    const handleCancel = () => {
        setFiles([])
        setVisible(false);
    };

    let text = "Hãy chọn tệp chứa dữ liệu cần khôi phục!"

    let {getRootProps, getInputProps, isDragActive} = useDropzone({onDrop: acceptedFiles =>{setFiles(acceptedFiles)}})

    const fileList = files.map(file => (
        <li key={file.path}>
            &#9864; {file.path} - {file.size} bytes
        </li>
    ));
    
    return (
        <Modal
            title={t("backupDatabase.restore")}
            centered={true}
            visible={isVisible}
            onOk={() => handleOk()}
            confirmLoading={confirmLoading}
            onCancel={() => handleCancel()}
            okText={t("backupDatabase.restore")}
            cancelText={t("sentencePage.cancel")}
        >
            <div {...getRootProps()} className={`upload-container ${isDragActive? "upload-container-active" : ""}`}>
                <input {...getInputProps()} />
                <FileAddOutlined />
                <div className={`upload-title`}>
                    { text }
                </div>
            </div>
            <div style={{marginTop: "10px"}}>
                {fileList}
            </div>
        </Modal>
    );
}

export default RestoreModal
